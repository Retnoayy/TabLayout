package com.retno.tablayout;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;

public class Tab3 extends AppCompatActivity implements TextWatcher {

    private String lifeCycle = "androidlifecycle";
    AutoCompleteTextView ac;
    EditText lv;
    String[] stringdatafak;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tab3);

        // Inisialisasi elemen UI
        ac = findViewById(R.id.dataautocmplte);
        lv = findViewById(R.id.datalstview);  // Ubah ID ke yang sesuai

        // Ambil array string dari resources
        stringdatafak = getResources().getStringArray(R.array.data_prodi);

        // Set TextWatcher
        ac.addTextChangedListener(this);
    }

    public void pilihprodi(View v) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Data Fakultas Ilmu Komputer Universitas Kuningan");
        builder.setItems(stringdatafak, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int item) {
                lv.setText(stringdatafak[item]);
                dialog.dismiss();
            }
        }).show();
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        // Implementasi Anda
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        // Implementasi Anda
    }

    @Override
    public void afterTextChanged(android.text.Editable s) {
        // Implementasi Anda
    }
}
